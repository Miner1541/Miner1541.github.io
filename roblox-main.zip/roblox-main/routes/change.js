import express from 'express'; 
import bcrypt from 'bcryptjs';
import User from '../model/register.js';
const router = express.Router();

router.post('/', async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username:username });
    console.log(user);
    if (!user) {
        return res.status(401).json({ message: 'User not found' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    await User.updateOne({ username }, { $set: { password: hashedPassword } });
    res.status(200).json({ message: 'Password updated successfully' });
}); 

export default router;