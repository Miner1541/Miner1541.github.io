import express from 'express';
import User_product from '../model/add.js';
import bodyParser from 'body-parser';

const router = express.Router();
router.use(bodyParser.urlencoded({ extended: true })); // For form-urlencoded data
router.use(bodyParser.json()); // For parsing JSON data

router.post('/', async (req, res) => {
    try {
        const { pname, stock, category, price, pusername, ppassword } = req.body;

        // Ensure pusername and ppassword are arrays
        const pusername_array = Array.isArray(pusername) ? pusername : [pusername];
        const ppassword_array = Array.isArray(ppassword) ? ppassword : [ppassword];

        // Check if all product usernames are unique

        // Construct the users object
        const puser = {};
        for (let i = 0; i < ppassword_array.length; i++) {
            puser[pusername_array[i]] = ppassword_array[i];
        }

        // Save the product data
        const product = new User_product({
            product_name: pname,
            stock: stock, // Stock can be a fixed number
            category:category,
            price: price,
            users: puser, // Assigning users to the product
        });

        await product.save();
        res.send('Product added successfully!');
    } catch (err) {
        console.error('Error:', err);
        res.status(500).send('Failed to add product.');
    }
});

export default router;
