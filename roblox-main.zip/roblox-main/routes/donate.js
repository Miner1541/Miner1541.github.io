import express from 'express';
import Users from '../model/register.js'

const router = express.Router();
router.use(express.json());
router.use(express.static('public'));

router.post('/', async (req, res) => {
    console.log(req.body);
    const {main_user, transfer_money} = req.body;
    const user = await Users.findOne({username: main_user});
    if(user.wallet < transfer_money){
        return res.status(400).json({message: "You do not have enough money"});
    }
    let wallet = user.wallet - transfer_money
    await Users.updateOne(
        { username: main_user },
        { $set: { wallet: wallet } }
    );
    res.status(200).json({message: "Donate successful"});   
});

export default router;