import express from 'express';
import bcrypt from 'bcryptjs';
import User from '../model/register.js';

const router = express.Router();

router.use(express.static('public'));

router.post('/', express.json(), async (req, res) => {
  const { username, password } = req.body;

  try {
    // Check if the user exists
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(401).json({ message: 'User does not exist' });
    }
    // Compare provided password with stored hashed password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(402).json({ message: 'Incorrect password' });
    }
    req.session.username = user.username;
    req.session.wallet = user.wallet
    // If login is successful 
    res.status(200).json({ message: 'Login successful'});
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

export default router
