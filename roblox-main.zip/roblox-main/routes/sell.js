import express from 'express';
import User_product from '../model/add.js';
import Users from '../model/register.js';

const router = express.Router();

// Middleware
router.use(express.json());
router.use(express.static('public'));

router.post('/', async (req, res) => {
  const { product_name, stock } = req.body;
  console.log(product_name, stock)

  try {
    // Check if the product exists
    const product = await User_product.findOne({ product_name });
    if (!product) {
      return res.status(400).json({ message: 'Product does not exist' });
    }

    // Check if the user exists

    const { price, users } = product;
    const stocks = product.stock;
    let wallet = req.session.wallet;

    // Check wallet balance
    if (wallet < price) {
      const amountNeeded = price - wallet;
      return res
        .status(401)
        .json({ message: `Insufficient funds. You need ${amountNeeded} more.` });
    }

    // Check stock availability
    if (stocks < stock) {
      return res.status(402).json({ message: `Not enough products` });
    }

    // Deduct price from wallet and update product stock
    wallet -= stock*price
    await User_product.updateOne(
      { product_name },
      { stock: stocks - stock}
    );
    await Users.updateOne(
      { username: req.session.username },
      { wallet: wallet }
    );

    // Update user's product list
    const updates = [];
    let dat = new Date();
    let dateValue = `${dat.getDate()}/${dat.getMonth() + 1}/${dat.getFullYear()}`;

    // Convert the map to an array and slice to get the first 'stock' entries
    const selectedUserEntries = Array.from(users.entries()).slice(0, stock); // Slice only the first 'stock' key-value pairs

    for (let i = 0; i < stock; i++) { // Loop over the stock
      console.log(`Processing product: ${product_name}, stock iteration: ${i}`);

      // Loop through the selected key-value pairs (first 'stock' entries)
      selectedUserEntries.forEach(([key, value]) => {
        updates.push({ 
          updateOne: {
            filter: { username: req.session.username },
            update: {
              $set: {
                // Add the dynamic key-value pair from users to the product's stock iteration
                [`users.${product_name}.0.${key}`]: value,  // Dynamic key-value pair
              },
            },
          },
        });
      });
    }

    // Perform a bulkWrite operation for all updates
    if (updates.length > 0) {
      await Users.bulkWrite(updates);
    }

    console.log("Updates completed.");

    await Users.updateOne({ username: req.session.username }, {
      $set: {
        [`users.${product_name}.1.Amount`]: price,  // Update Amount for each stock iteration
        [`users.${product_name}.1.Date`]: dateValue, // Update Date for each stock iteration
      }
    })
    const usersObj = {};
    users.forEach((value, key) => {
      usersObj[key] = value; // Add each entry to a plain object
    });
    const userKeys = Object.keys(usersObj); // Get the user keys (e.g., ["3", "5"])
    const entriesToRemove = Math.min(stock, userKeys.length); // Determine how many entries to remove

    const deletions = [];
    for (let i = 0; i < entriesToRemove; i++) {
      const userKeyToRemove = userKeys[i]; // Get the user key to remove

      deletions.push(
        User_product.updateOne(
          { product_name },
          { $unset: { [`users.${userKeyToRemove}`]: "" } } // Remove the user entry from the product
        )
      );
    }
    await Promise.all(deletions);

    req.session.wallet = wallet

    // Success response
    res.status(200).json({ message: 'Purchase successful' });
  } catch (error) {
    console.error('Error during purchase:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

export default router;
