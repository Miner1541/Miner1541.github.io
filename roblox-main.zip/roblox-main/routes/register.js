import express from 'express';
import bcrypt from 'bcryptjs';
import Users from '../model/register.js';
import bodyParser from 'body-parser';

const router = express.Router();
router.use(express.static('public')); 
router.use(bodyParser.json());
router.use(express.json())

router.post('/', async (req, res) => {
  const { username, email, password } = req.body;

  console.log('Received registration data:', { username, email });  // Don't log passwords

  try {
    // Password validation
    if (password.length < 8) {
      return res.status(400).json({ message: 'Password must be at least 8 characters long' });
    }
    
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordRegex.test(password)) {
      return res.status(400).json({ message: 'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character' });
    }

    const user = await Users.findOne({ username });
    const emails = await Users.findOne({ email });
    if (user) {
      console.log("User already exists");
      return res.status(409).json({ message: 'User already exists' });
    }
    if (emails) {
      console.log("Email already exists");
      return res.status(409).json({ message: 'Email already in use' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new Users({ username, password: hashedPassword, email });
    await newUser.save();
    req.session.username = newUser.username;
    req.session.wallet = newUser.wallet;

    res.status(200).json("Registration Successful");
  } catch (error) {
    console.error('Error during registration:', error);
    res.status(500).json({ message: 'Server error, please try again later.' });
  }
});

export default router;
