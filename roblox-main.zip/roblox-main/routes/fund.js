import express from 'express';
import Users from '../model/register.js';

export const router = express.Router();

router.use(express.json());
router.use(express.static('public'));

router.post("/", async (req, res) => {
    const { main_user, transfer_user, transfer_money } = req.body;

    try {
        const user = await Users.findOne({ username: main_user });
        const user_2 = await Users.findOne({ username: transfer_user });

        // Check for insufficient funds
        if (transfer_money > user.wallet) {
            return res.status(400).json({ message: "You do not have enough money" });
        }

        // Check if the receiving user exists
        if (!user_2) {
            return res.status(401).json({ message: "Recipient user not found" });
        }
        if (user === user_2) {
            return res.status(402).json({ message: "Same user" });
        }
        let wallet = user.wallet - transfer_money
        // Update wallets
        await Users.updateOne(
            { username: main_user },
            { $set: { wallet: wallet } }
        );
        await Users.updateOne(
            { username: transfer_user },
            { $set: { wallet: user_2.wallet + transfer_money } }
        );

        // Ensure thistory is an array
        await Users.updateMany(
            { thistory: { $exists: true, $not: { $type: "array" } } },
            { $set: { thistory: [] } }
        );

        // Send alert via Socket.IO
        const message = `You have received ${transfer_money} from ${main_user}.`;
        let date = new Date().getTime();
        await Users.updateOne(
            { username: transfer_user },
            { $push: { thistory: { message, date } } } 
        );

        req.session.wallet = wallet
        return res.status(200).json({ message: "Transfer successful" });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Internal Server Error" });
    }
});

export default router;
