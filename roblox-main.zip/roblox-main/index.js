import express from 'express'; 
import session from 'express-session';
import mongoose from 'mongoose';
import User_product from './model/add.js';
import User from './model/register.js';
import sellRouter from './routes/sell.js';
import donateRouter from './routes/donate.js';
import loginRouter from './routes/login.js';
import registerRouter from './routes/register.js';
import addRouter from './routes/add.js';
import changeRouter from './routes/change.js';
import fundRouter from './routes/fund.js';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env file with proper path handling
dotenv.config({ path: path.resolve(__dirname, '.env') });




const app = express();
const port = 4000;

// Session middleware 
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'default_secret',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 5 * 24 * 60 * 60 * 1000 },
  })
);

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('Connected to MongoDB successfully!');
  })
  .catch((err) => {
    console.error('Error connecting to MongoDB:', err.message);
  });


app.use(express.static('public'));
app.use(express.json());
app.use('/logined', loginRouter);
app.use('/regist', registerRouter);
app.use('/adding', addRouter);
app.use('/selling', sellRouter);
app.use('/fund', fundRouter);
app.use('/change', changeRouter);
app.use('/donate', donateRouter);

function Setting_name(req, res, next) {
  if (!req.session.username) {
    req.session.username = 'You Are not logged in';
  }
  if (!req.session.wallet) {
    req.session.wallet = 0;
  }
  next();
}

app.get('/', async (req, res) => {
  const message = req.query.message || '';
  console.log(message);
  res.sendFile(path.join(__dirname, '/public/html/index.htm'));
});

app.post('/showing', Setting_name, async (req, res) => {
  try {
    const product = await User_product.find();
    let show_user = req.session.username;
    let wallet = req.session.wallet;
    res.json({ product, show_user, wallet });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  } 
});

app.post('/showing/history', async (req, res) => {
  try {
    let show_user = req.session.username;

    // Ensure the user is logged in
    if (!show_user) {
      return res.status(400).json({ error: 'User not logged in or session expired' });
    }

    // Find the user by their username
    const user = await User.findOne({ username: show_user });

    // Check if the user exists and has a history
    if (!user || !user.thistory) {
      console.log("No history found or user doesn't exist.");
      return res.status(404).json({ error: 'User or history not found' });
    }

    const currentTime = new Date().getTime();  // Current time in milliseconds
    const twentyFourHoursAgo = currentTime -(24 * 60 * 60 * 1000); // 24 hours in milliseconds

    // Handle both array and object formats of thistory
    let updatedHistory;

    if (Array.isArray(user.thistory)) {
      // If thistory is an array, filter it
      updatedHistory = user.thistory.filter(entry => entry.date >= twentyFourHoursAgo);
    } else if (typeof user.thistory === 'object') {
      // If thistory is an object, filter key-value pairs
      updatedHistory = {};
      for (const [key, value] of Object.entries(user.thistory)) {
        if (value.date >= twentyFourHoursAgo) {
          updatedHistory[key] = value;
        }
      }
    } else {
      return res.status(500).json({ error: 'Unexpected thistory format' });
    }

    // Update the thistory field in the database
    user.thistory = updatedHistory;
    await user.save(); // Save the entire user document with the updated history

    console.log("Old messages removed successfully.");
    res.json({ user }); // Return the whole user object
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});


app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, '/public/html/register.htm'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '/public/html/login.htm'));
}); 

app.get('/history', (req, res) => {
  res.sendFile(path.join(__dirname, '/public/html/history.htm'));
});

app.get('/addingproductto', (req, res) => {
  if (req.session.username === 'ADMIN') {
    res.sendFile(path.join(__dirname, '/public/html/add.htm'));
  } else {
    res.status(403).json('ADMIN access only');
  }
});

app.post('/delete', async(req,res)=>{
  const {product} = req.body
  await User_product.deleteOne({product_name:product})
  res.status(200).json("Successful")
})

app.get('/changer', async(req,res)=>{
  if (req.session.username === 'ADMIN') {
    res.sendFile(path.join(__dirname, '/public/html/change.htm'));
  } else {
    res.status(403).json('ADMIN access only');
  }
})
// 404 Handler
app.use((req, res) => {
  res.sendFile(path.join(__dirname, '/public/html/404.htm'));
});

// Error Handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});