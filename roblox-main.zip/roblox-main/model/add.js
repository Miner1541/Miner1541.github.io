import mongoose from 'mongoose';

// User Schema
const productSchema = new mongoose.Schema({
  product_name: { type: String, required: true },
  stock: { type: Number, required: true },
  category:{type:String, required: true},
  price: { type:Number, required: true },
  users: { type: Map, of: String }, // Users as a map of username-password pairs
});

// Export the model
export default mongoose.model('Product', productSchema);
