import mongoose from 'mongoose';

const register_structure = new mongoose.Schema({
    username:{type:String},
    email:{type:String},
    password:{type:String},
    time:  {type: Date, default: Date.now},
    wallet:{type: Number, default: 0},
    users: { type: Map},
    thistory:{type: [
        {
          message: { type: String },
          date: { type: Number },
        },
      ],
      default: [],}
})

const User = mongoose.model('User', register_structure);
export default User