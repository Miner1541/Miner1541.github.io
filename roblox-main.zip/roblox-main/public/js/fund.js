let link = document.getElementById("funding")
let id = document.getElementById("show")
let main_user = id.innerText
let alert_main = document.querySelector('.alert_main');
let warning_main = document.getElementById('warning_main');
function show(main, content, bool, message) {
    console.log("entered");

    if (!main || !content) {
        console.error('Main or content element not found');
        return;
    }

    if (bool === true) {
        main.classList.remove("alert-danger");
        main.classList.add("alert-success");
    } else {
        main.classList.remove("alert-success");
        main.classList.add("alert-danger");
    }

    main.classList.remove("d-none");
    content.innerText = message;

    // Ensure that the close button is available and event listener is added after showing the alert
    const button = main.querySelector(".btn-close"); // Assuming the close button is within the alert element
    if (button) {
        button.addEventListener("click", () => {
            main.classList.add("d-none"); // Hide the alert when close button is clicked
        });
    }
}


document.getElementById("form1").addEventListener("submit", async (e) => {
    e.preventDefault()
    let alerts = document.querySelector('.alert2');
    let warning = document.getElementById('warning2');
    const main_user = document.getElementById("show").innerText
    const transfer_user = document.getElementById("user_name").value
    const transfer_money = document.getElementById("fund_transfer").value
    if (!transfer_user.trim() || !transfer_money.trim()) {
        show(alerts, warning, false, "All fields are required. Please fill them out.");
        return; // Stop further execution
    }
    const data = {
        main_user: main_user,
        transfer_user: transfer_user,
        transfer_money: parseInt(transfer_money)
    }
    console.log(data)
    await axios.post("/fund", data)
        .then((response) => {
            if (response.status === 200) {
                let recieved = "Fund has Successfull transfered"
                show(alerts, warning, true, recieved)
            }
        }).catch((error) => {
            console.error(error)
            let errorMessage
            if (error.response) {
                switch (error.response.status) {
                    case 400:
                        errorMessage = 'You do not have enough money.';
                        break;
                    case 401:
                        errorMessage = 'The user is not available.';
                        break;
                    case 402:
                        errorMessage = "You can't send money to yourself."    
                    case 500:
                        errorMessage = 'There was an error with the request. Please try again.';
                        break;
                }
            }
            warning.innerText = errorMessage;
            alerts.classList.remove("d-none");
        });
})

link.addEventListener("click", () => {
    const main_user = document.getElementById("show").innerText
    let errror_message = "You are not Register/Login"
    console.log(main_user)
    if (main_user === 'You Are not logged in') {
        show(alert_main, warning_main, false, errror_message)
    }
    else {
        link.setAttribute("data-bs-toggle", "modal");
        link.setAttribute("data-bs-target", "#fund");
        let model = new bootstrap.Modal(document.getElementById("fund"))
        let fundmodal = document.getElementById("fund")
        model.show()
        fundmodal.addEventListener("hidden.bs.modal", () => {
            let backdrop = document.querySelector(".modal-backdrop")
            if (backdrop) {
                backdrop.remove(); // Remove backdrop if it exists
            }
        })
    }
})

async function showing() {
    await axios.post("/showing/history")
    .then((response) => {
        console.log(response);
        const user_data = response.data.user;
        console.log(user_data.thistory)

        // Check if thistory exists and is not empty
        if (user_data.thistory && Object.keys(user_data.thistory).length > 0) {
            
            const messageCount = Object.keys(user_data.thistory).length;
            console.log(messageCount);

            // Get the last entry from thistory
            const lastMessageKey = Object.keys(user_data.thistory)[messageCount - 1];
            const lastMessage = user_data.thistory[lastMessageKey];

            console.log(lastMessage.message);
            show(alert_main, warning_main, true, lastMessage.message)
        } else {
            console.log("No messages found.");
        }
    }).catch((err) => {
        console.log(err);
    });
}

showing();
