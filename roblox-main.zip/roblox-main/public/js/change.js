function show(main, content, bool, message) {
    if (bool === true) {
        main.classList.remove("alert-danger");
        main.classList.add("alert-success");
    } else {
        main.classList.remove("alert-success");
        main.classList.add("alert-danger");
    }
    main.classList.remove("d-none");
    content.innerText = message;

    // Ensure that the close button is available and event listener is added after showing the alert
    const button = main.querySelector(".btn-close"); // Assuming the close button is within the alert element
    if (button) {
        button.addEventListener("click", () => {
            main.classList.add("d-none"); // Hide the alert when close button is clicked
        });
    }
}

document.getElementById("form").addEventListener("submit", async e => {
    e.preventDefault();
    console.log("Form submitted");
    let main = document.getElementById("alertBox");
    let content = document.getElementById("warning");
    const password = document.getElementById("password").value;
    const username = document.getElementById("username").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    if (password !== confirmPassword) {
        return show(main, content, false, "Passwords do not match");
    } else {
        console.log("Passwords match");
    }
    const data = {
        username,
        password
    }
    console.log(data);
    axios.post("/change", data)
        .then((result) => {
            console.log(result);
            if(result.status === 200){
                show(main, content, true, "Password updated successfully");
            }
        }).catch((err) => {
            console.log(err);
            switch (err.response.status) {
                case 401:
                    show(main, content, false, "User not found");
                    break;
                default:
                    show(main, content, false, "Something went wrong");
                    break;
            }
        });
});

