let link = document.getElementById("donating")
let id = document.getElementById("show")
let main_user = id.innerText
let alert_main = document.querySelector('.alert_main');
let warning_main = document.getElementById('warning_main');
function show(main, content, bool, message) {
    console.log("entered");

    if (!main || !content) {
        console.error('Main or content element not found');
        return;
    }

    if (bool === true) {
        main.classList.remove("alert-danger");
        main.classList.add("alert-success");
    } else {
        main.classList.remove("alert-success");
        main.classList.add("alert-danger");
    }

    main.classList.remove("d-none");
    content.innerText = message;

    // Ensure that the close button is available and event listener is added after showing the alert
    const button = main.querySelector(".btn-close"); // Assuming the close button is within the alert element
    if (button) {
        button.addEventListener("click", () => {
            main.classList.add("d-none"); // Hide the alert when close button is clicked
        });
    }
}


document.getElementById("form2").addEventListener("submit", async (e) => {
    e.preventDefault()
    let alerts = document.querySelector('.alert3');
    let warning = document.getElementById('warning3');
    const main_user = document.getElementById("show").innerText
    const transfer_money = document.getElementById("donate_amount").value
    if (!transfer_money.trim()) {
        show(alerts, warning, false, "All fields are required. Please fill them out.");
        return; // Stop further execution
    }
    const data = {
        main_user: main_user,
        transfer_money: parseInt(transfer_money)
    }
    await axios.post("/donate", data)
        .then((response) => {
            if (response.status === 200) {
                let recieved = "Thank you for your donation"
                show(alerts, warning, true, recieved)
            }
        }).catch((error) => {
            console.error(error)
            let errorMessage
            if (error.response) {
                switch (error.response.status) {
                    case 400:
                        errorMessage = 'You do not have enough money.';
                        break;
                    case 500:
                        errorMessage = 'There was an error with the request. Please try again.';
                        break;
                }
            }
            show(alerts, warning, false, errorMessage)
        });
})

link.addEventListener("click", () => {
    const main_user = document.getElementById("show").innerText
    let errror_message = "You are not Register/Login"
    console.log(main_user)
    if (main_user === 'You Are not logged in') {
        show(alert_main, warning_main, false, errror_message)
    }
    else {
        link.setAttribute("data-bs-toggle", "modal");
        link.setAttribute("data-bs-target", "#donate");
        let model = new bootstrap.Modal(document.getElementById("donate"))
        let fundmodal = document.getElementById("donate")
        model.show()
        fundmodal.addEventListener("hidden.bs.modal", () => {
            let backdrop = document.querySelector(".modal-backdrop")
            if (backdrop) {
                backdrop.remove(); // Remove backdrop if it exists
            }
        })
    }
})
