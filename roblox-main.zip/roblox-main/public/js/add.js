function show(main, content, bool, message) {
    if (bool === true) {
        main.classList.remove("alert-danger");
        main.classList.add("alert-success");
    } else {
        main.classList.remove("alert-success");
        main.classList.add("alert-danger");
    }
    main.classList.remove("d-none");
    content.innerText = message;
    
    // Ensure that the close button is available and event listener is added after showing the alert
    const button = main.querySelector(".btn-close"); // Assuming the close button is within the alert element
    if (button) {
        button.addEventListener("click", () => {
            main.classList.add("d-none"); // Hide the alert when close button is clicked
        });
    }
}

document.getElementById('add').addEventListener("click", () => {
    const div = document.createElement('div');
    div.innerHTML = `
    <hr>
    <div class="mb-4 p-1">
        <label for="text" class="form-label">Product's username</label>
        <input type="text" class="form-control pusername" placeholder="Enter your Product's username">
    </div>
    <div class="mb-4 p-1">
        <label for="password" class="form-label">Product's Password</label>
        <input type="password" class="form-control ppassword" placeholder="Enter your Product's password">
    </div>
    `;
    document.getElementById('detail').appendChild(div);
});

document.getElementById('form').addEventListener("submit", async (e) => {
    e.preventDefault();
    const pname = document.getElementById('pname').value;
    const stock = parseInt(document.getElementById('stock').value, 10); // stock value from the input field
    const category = document.getElementById("category").value
    const price = parseInt(document.getElementById('price').value, 10);


    // Collect pusername and ppassword arrays, filter out blank entries
    const pusername = [];
    document.querySelectorAll('.pusername').forEach(e => {
        const value = e.value;
        if (value !== "") { // Only add non-empty values
            pusername.push(value);
        }
    });

    const ppassword = [];
    document.querySelectorAll('.ppassword').forEach(e => {
        const value = e.value;
        if (value !== "") { // Only add non-empty values
            ppassword.push(value);
        }
    });

    let alerts = document.querySelector('.alert');
    let warning = document.getElementById('warning');

    if (!pname.trim()  || isNaN(stock), isNaN(price)) {
        show(alerts, warning, false, "All fields are required. Please fill them out.");
        return; // Stop further execution
    }

    // **Check 1: Ensure the product usernames are unique**
    const uniqueUsernames = new Set(pusername);
    if (pusername.length !== uniqueUsernames.size) {
        return show(alerts, warning, false, 'Product usernames must be unique.');
    }

    // **Check 2: Ensure the number of usernames matches the number of passwords**
    if (pusername.length !== ppassword.length) {
        return show(alerts, warning, false, 'Each product username must have a corresponding password.');
    }

    

    if (pusername.length !== stock) {
        return show(alerts, warning, false, 'The number of usernames does not match the stock quantity.');
    }

    // If all checks pass, send the data to the backend
    const sender = async () => {
        const data = {
            pname: pname,
            stock: stock,
            category:category,
            price: price,
            pusername: pusername,
            ppassword: ppassword
        };
        console.log(data)
        try {
            const response = await axios.post('/adding', data);
            console.log('Response:', response.data);

            if (response.status === 200) {
                // Redirect after successful addition
                window.location.href = '/';
            }
        } catch (error) {
            console.error('Error:', error.message);
            let errorMessage = 'There was an error with the request. Please try again.';
            show(alerts, warning, false, errorMessage);
        }
    };

    sender();
});


