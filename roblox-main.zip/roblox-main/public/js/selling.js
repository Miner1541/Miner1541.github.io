function show(main, content, bool, message) {
    if (bool === true) {
        main.classList.remove("alert-danger");
        main.classList.add("alert-success");
    } else {
        main.classList.remove("alert-success");
        main.classList.add("alert-danger");
    }
    main.classList.remove("d-none");
    content.innerText = message;

    // Ensure that the close button is available and event listener is added after showing the alert
    const button = main.querySelector(".btn-close"); // Assuming the close button is within the alert element
    if (button) {
        button.addEventListener("click", () => {
            main.classList.add("d-none"); // Hide the alert when close button is clicked
        });
    }
}

document.getElementById("form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const alerts = document.querySelector('.alert0');
    const warning = document.getElementById('warning');
    const stock = document.getElementById('stock_buy').value;
    const product_name = document.getElementById('product_name').placeholder;

    if (stock.trim() === '') {
        show(alerts, warning, false, "Enter your desired product counts");
        return;
    }

    // Include buttonData in the request payload
    const data = {
        product_name: product_name,
        stock: parseInt(stock),
    };

    try {
        const response = await axios.post('/selling', data);
        console.log('Response:', response.data);

        if (response.status === 200) {
            // Redirect to the success page after login
            window.location.href = "/history";
        }
    } catch (error) {
        console.log('Received error response:', error);
        let errorMessage;
        if (error.response) {
            switch (error.response.status) {
                case 400:
                    errorMessage = 'Product not available';
                    break;
                case 401:
                    errorMessage = 'You have Insufficient money in your wallet.';
                    break;
                case 402:
                    errorMessage = 'The Stock does not have as much as you want';
                    break;
                case 500:
                    errorMessage = 'There was an error with the request. Please try again.';
                    break;
            }
        }
        show(alerts, warning, false, errorMessage); // Show error message
    }
});
