function show(main, content, bool, message) {
    if (bool === true) {
        main.classList.remove("alert-danger");
        main.classList.add("alert-success");
    } else {
        main.classList.remove("alert-success");
        main.classList.add("alert-danger");
    }
    main.classList.remove("d-none");
    content.innerText = message;

    // Ensure that the close button is available and event listener is added after showing the alert
    const button = main.querySelector(".btn-close"); // Assuming the close button is within the alert element
    if (button) {
        button.addEventListener("click", () => {
            main.classList.add("d-none"); // Hide the alert when close button is clicked
        });
    }
}

document.getElementById("form").addEventListener("submit", async e => {
    e.preventDefault();  // Prevent form default submission

    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const repassword = document.getElementById("repassword").value;
    
    let alerts = document.querySelector('.alert'); // This assumes `.alert` is the class for the alert container
    let warning = document.getElementById('warning'); // This should match the ID in your HTML

    console.log(username, email, password, repassword);

    if (!username.trim() || !email.trim() || !password.trim() || !repassword.trim()) {
        show(alerts, warning, false, "All fields are required. Please fill them out.");
        return; // Stop further execution
    }
    // Check if password and repassword match
    if (password !== repassword) {
        // Show alert if passwords do not match
        return show(alerts, warning, false, "Passwords do not match. Please try again.")
          // Prevent further code execution if passwords don't match
    }

    // Send the registration data to backend
    const sendData = async () => {
        const data = {
            username: username,
            email: email,
            password: password
        };

        try {
            const response = await axios.post('/regist', data);
            console.log('Response:', response.data);
            if (response.status === 200) {
                // Redirect to the page after registration
                window.location.href = '/';
            } 
        } catch (error) {
            let errorMessage = 'There was an error with the request. Please try again.';
            console.log(error)
            if (error.response) {
                switch (error.response.status) {
                    case 400:
                        errorMessage = error.response.data.message;
                        break;
                    case 409: // Conflict, user/email already exists
                        errorMessage = 'The user or email already exists. Please try again';
                        break;
                    case 500:
                        errorMessage = 'There was a server error. Please try again later.';
                        break;
                    default:
                        errorMessage = 'An unexpected error occurred.';
                }
            }
            show(alerts, warning, false, errorMessage)
        }
    };

    // Call sendData function to send data
    sendData();
});
