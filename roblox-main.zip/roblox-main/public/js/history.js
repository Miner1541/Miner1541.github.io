async function User_showing() {
    await axios.post('/showing/history')
        .then((response) => {
            console.log(response); // Log the entire response object
            const user_data = response.data.user
            let table = document.querySelector("tbody")
            let modal_table = document.getElementById("modal-tbody")
            document.getElementById("wallet").innerHTML = user_data.wallet
            document.getElementById("show").innerHTML = user_data.username
            const time = []
            const price = []
            const productkeys = Object.keys(user_data.users);

            for (let i = 0; i < productkeys.length; i++) {
                time.push(user_data.users[productkeys[i]][1].Date)
                price.push(user_data.users[productkeys[i]][1].Amount)
            }

            for (let i = 0; i < productkeys.length; i++) {
                const data = `<tr>
                    <td><span>${productkeys[i]}</span></td>
                    <td><span>${time[i]}</span></td>
                    <td><span>$${price[i]}</span></td>
                    <td><button type="button" class="btn btn-outline-info info" id="info${i}" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                        <svg class="icon bi-eye-fill" width="25" height="25">
                            <use href="img/info.svg#bi-eye-fill"></use>
                        </svg>
                    </button></td>
                    <td><span>Completed</span></td>
                    </tr>`
                table.innerHTML += data
            } 
            productkeys.forEach((productKey, index) => {
                document.getElementById(`info${index}`).addEventListener('click', () => {
                    const details = user_data.users[productKey][0]; // Extract the 0: {key: value} part
                    modal_table.innerHTML = ""
                    // Format the details into a string for display
                    for (const [key, value] of Object.entries(details)) {
                        const data_user = `<tr>
                        <td><span>${key}</span></td>
                        <td><span>${value}</span></td>
                        </tr>`
                        modal_table.innerHTML += data_user
                    }
                });
            });
        }).catch((err) => {
            console.error('There was an error fetching the data!', err);
        });

}


User_showing();
