function show(main, content, bool, message) {
    if (bool === true) {
        main.classList.remove("alert-danger");
        main.classList.add("alert-success");
    } else {
        main.classList.remove("alert-success");
        main.classList.add("alert-danger");
    }
    main.classList.remove("d-none");
    content.innerText = message;

    // Ensure that the close button is available and event listener is added after showing the alert
    const button = main.querySelector(".btn-close"); // Assuming the close button is within the alert element
    if (button) {
        button.addEventListener("click", () => {
            main.classList.add("d-none"); // Hide the alert when close button is clicked
        });
    }
}

document.getElementById("form").addEventListener("submit", async e => {
    console.log("Form submit");
    e.preventDefault(); // Prevent form default submission

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    let alerts = document.querySelector('.alert'); // Ensure this element exists in your HTML
    let warning = document.getElementById('warning'); // Ensure this element exists in your HTML

    console.log(username);
    console.log(password);

    if (!username.trim() || !password.trim()) {
        show(alerts, warning, false, "All fields are required. Please fill them out.");
        return; // Stop further execution
    }
    
    // Define the function to send data to the backend
    const sendData = async () => {
        const data = {
            username: username,
            password: password
        };
        try {
            const response = await axios.post('/logined', data);
            console.log('Response:', response.data);
            if (response.status === 200) {
                window.location.href = '/';
            }
        } catch (error) {
            console.log('Received error response:', error);

            let errorMessage = 'There was an error with the request. Please try again.';
            if (error.response) {
                switch (error.response.status) {
                    case 401:
                        errorMessage = 'The user does not exist. Please try again.';
                        break;
                    case 402:
                        errorMessage = 'The password is incorrect. Please try again.';
                        break;
                }
            }

            // Set the warning message and make the alert visible
            show(alerts, warning, false, errorMessage)
        }
    };

    // Call sendData function to send data
    sendData();
});
