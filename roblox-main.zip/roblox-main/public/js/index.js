function show(main, content, bool, message) {
  if (bool === true) {
    main.classList.remove("alert-danger");
    main.classList.add("alert-success");
  } else {
    main.classList.remove("alert-success");
    main.classList.add("alert-danger");
  }
  main.classList.remove("d-none");
  content.innerText = message;

  // Ensure that the close button is available and event listener is added after showing the alert
  const button = main.querySelector(".btn-close"); // Assuming the close button is within the alert element
  if (button) {
    button.addEventListener("click", () => {
      main.classList.add("d-none"); // Hide the alert when close button is clicked
    });
  }
}


let alert_main = document.querySelector('.alert_main');
let link = document.querySelector(".link-secondary")
let warning_main = document.getElementById('warning_main');
let id = document.getElementById("show")
let admin = document.getElementById('adminLink')

async function Productss() {
  await axios.post('/showing')
    .then((response) => {
      const products = response.data.product;
      let table = document.querySelector("tbody");
      let wallet = document.getElementById("wallet");
      let id = document.getElementById("show");
      wallet.innerText = response.data.wallet
      id.innerText = response.data.show_user
      const isAdmin = id.innerText === "ADMIN";
      if (isAdmin) {
        admin.classList.remove('d-none')
      }

      // Add table headers conditionally
      // Create a dropdown for categories
      let categories = [...new Set(products.map(product => product.category))]; // Extract unique categoriesclass=""
      let categoryDropdown = `<select id="categoryFilter" class="form-select ">
                          <option value="all">All Categories</option>
                          ${categories.map(category => `<option value="${category}">${category}</option>`).join("")}
                        </select>`;

      // Add the dropdown to the table header or above the table
      let dropdownContainer = document.getElementById("dropdownContainer"); // Assuming you have a container for the dropdown
      dropdownContainer.innerHTML = categoryDropdown;

      // Add the table header
      let tableHeader = `<tr class="header">
          <th>Product Name</th>
          <th>Stock</th>
          <th>Price</th>
          ${isAdmin ? "<th>Action</th>" : ""}
        </tr>`;
      table.innerHTML = tableHeader; // Clear existing content and add header

      // Render products
      function renderProducts(filteredProducts) {
        table.innerHTML = tableHeader; // Reset table and add header

        for (let i = 0; i < filteredProducts.length; i++) {
          let price_show = filteredProducts[i].stock == 0 ? "DM ADMIN" : `$${filteredProducts[i].price}`;

          const removeButton = isAdmin
            ? `<button type="button" class="btn btn-outline-danger item_remove" data-bs-target="#remove">Remove</button>`
            : ""; // Render nothing if the user is not an admin

          const data = `<tr>
          <td id='product${i}'>${filteredProducts[i].product_name}</td>
          <td><span><img src="img/availabe.svg" alt=""><span class="stock">${filteredProducts[i].stock}</span></span></td>
          <td><button type="button" class="btn btn-outline-success price item_purchase" data-bs-target="#sell">${price_show}</button></td>
          ${isAdmin ? `<td>${removeButton}</td>` : ""} <!-- Only add 'Remove' column for admin -->
        </tr>`;

          table.innerHTML += data;
        }

        // Attach event listeners to the dynamically created "Sell" buttons
        let when_selling = document.querySelectorAll(".item_purchase");
        for (let i = 0; i < when_selling.length; i++) {
          when_selling[i].addEventListener("click", () => {
            if (id.innerText === 'You Are not logged in') {
              alert_main.classList.remove('d-none');
              warning_main.innerHTML = "You are not Register/Login";
            } else {
              let price_show = filteredProducts[i].stock === 0 ? "DM ADMIN" : `$${filteredProducts[i].price}`;

              if (price_show === "DM ADMIN") {
                return; // Exit if the product stock is 0
              }
              when_selling[i].setAttribute("data-bs-toggle", "modal");

              document.getElementById("product_name").placeholder = document.getElementById(`product${i}`).innerText;

              let stock = document.getElementById('stock_buy');
              stock.addEventListener('input', () => {
                const stockBuyInput = parseInt(stock.value, 10) || 0; // Parse input value on every change, default to 0
                document.getElementById("product_price").placeholder = `$ ${stockBuyInput * filteredProducts[i].price}`;
              });

              const modal = new bootstrap.Modal(document.getElementById('sell'));
              modal.show();
              const sellModal = document.getElementById('sell');
              sellModal.addEventListener('hidden.bs.modal', function () {
                // Reset backdrop manually if it stays visible after modal closes
                const backdrop = document.querySelector('.modal-backdrop');
                if (backdrop) {
                  backdrop.remove(); // Remove backdrop if it exists
                }
              });
            }
          });
        }

        // Attach event listeners to the dynamically created "Remove" buttons (if admin)
        let when_removeing = document.querySelectorAll(".item_remove");
        for (let i = 0; i < when_removeing.length; i++) {
          when_removeing[i].addEventListener("click", () => {
            if (!isAdmin) {
              show(alert_main, warning_main, false, "You are not ADMIN");
            } else {
              when_removeing[i].setAttribute("data-bs-toggle", "modal");
              let modal = new bootstrap.Modal(document.getElementById("remove"));
              modal.show();
              let modalParagraph = document.querySelector("#remove .modal-body p");
              modalParagraph.innerHTML = `Are you sure you want to remove <strong>${filteredProducts[i].product_name}</strong>?`;

              let remove = document.getElementById("remove");
              remove.addEventListener("hidden.bs.modal", () => {
                let backdrop = document.querySelector(".modal-backdrop");
                if (backdrop) {
                  backdrop.remove();
                }
              });
            }
          });
        }
      }

      // Initial rendering of all products
      renderProducts(products);

      // Event listener for category filtering
      document.getElementById("categoryFilter").addEventListener("change", (e) => {
        const selectedCategory = e.target.value;
        if (selectedCategory === "all") {
          renderProducts(products); // Show all products
        } else {
          const filteredProducts = products.filter(product => product.category === selectedCategory);
          renderProducts(filteredProducts); // Show filtered products
        }
      });

    })
    .catch(error => {
      // Handle error
      console.error('There was an error fetching the data!', error);
    });
}

Productss();


link.addEventListener("click", async (e) => {
  e.preventDefault()
  console.log("Hi")
  if (id.innerText === 'You Are not logged in') {
    alert_main.classList.remove('d-none');
    warning_main.innerHTML = "You are not Register/Login"
  }
  else {
    window.location.href = "/history"
  }
})

document.querySelector("#add").addEventListener("click", (e) => {
  e.preventDefault()
  console.log("Admin")

  if (id.innerText !== "ADMIN") {
    alert_main.classList.remove('d-none');
    warning_main.innerHTML = "You are not ADMIN"
  }
  else {
    window.location.href = "/addingproductto"
  }
})

let alerts = document.querySelector('.alert');
document.querySelector(".btn-close").addEventListener("click", () => {
  alerts.classList.add('d-none');
})


let removebutton = document.getElementById('removebutton')

removebutton.addEventListener("click", async () => {
  let product = document.querySelector("#remove .modal-body p strong").innerText
  console.log(product)
  const message = {
    product: product
  }
  await axios.post("/delete", message)
    .then((result) => {
      console.log(result)
      if (result.status === 200) {
        let modal = bootstrap.Modal.getInstance(document.getElementById("remove"))
        let backdrop = document.querySelector(".modal-backdrop")
        modal.hide()
        backdrop.remove()
        show(alert_main, warning_main, true, "Product has Successfuly deleted")
      }
    }).catch((err) => {
      console.error(err)
      show(alerts, warning, false, 'There was an error with the request. Please try again.')
    });
})






// I_DONT_KNOW